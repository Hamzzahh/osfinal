#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void *worker1(void *arg) {

  int number = *(int *)arg;

  int *sum = malloc(sizeof(int));

  for (int i = 0; i <= number; i++) {
    *sum += i;
  }

  printf("the sum is : %d\n", *sum);

  pthread_exit(sum); // in exit we can send points of any kind
}

int main(int argc, char **argv) {

  int number;

  printf("Enter any number");

  if (scanf("%d", &number) != 1) {
    printf("Invalid input. Exiting...\n");
    return 1;
  }

  pthread_t thread1;

  pthread_create(&thread1, NULL, worker1, &number);

  void *sum;

  pthread_join(thread1, &sum);

  int *summation = (int *)sum; // converting void pointer to int pointer

  printf("The sum of numbers from 1 till user entered number %d is : %d\n",
         number, *summation);

  return 0;
}
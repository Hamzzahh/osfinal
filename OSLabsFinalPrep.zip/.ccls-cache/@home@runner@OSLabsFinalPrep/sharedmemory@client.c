#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>

#define KEY 99
#define SIZE 20

int main(int argc, char **argv) {

  FILE *file;

  file = fopen(argv[2], "r");

  int n = atoi(argv[1]);

  char array[SIZE];

  int i;

  if (fgets(array, SIZE, file) == NULL) {
    printf("Failed to read from file.\n");
    return 1;
  }

  printf("the array is : %s\n", array);

  int id = 0;
  char *ptr;
  int unlink_status = 0;

  id = shmget(KEY, SIZE, IPC_CREAT);

  if (id < 0) {
    printf("SHMGET failed\n");
    return 2;
  } else {
    printf("ID : %d\n", KEY);
  }

  ptr = shmat(id, NULL, 0);

  if (ptr == NULL) {
    printf("SHMAT failed\n");
  }

  strcpy(ptr, array);

  unlink_status = shmdt(ptr);

  if (unlink_status < 0) {
    printf("SHMDT failed\n");
    return 3;
  }

  shmctl(KEY, IPC_RMID, NULL);
  return 0;
}

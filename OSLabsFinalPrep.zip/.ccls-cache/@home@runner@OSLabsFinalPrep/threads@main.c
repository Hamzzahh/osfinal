#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void *worker1() {

  pthread_t threadID = pthread_self();
  pid_t process_id = getpid();

  printf("Thread ID : %lu\n | process ID : %d\n", (unsigned long)threadID,
         process_id);

  pthread_exit(0);
}

int main(int argc, char **argv) {

  int numOfThreads = 0;
  printf("Enter number of threads");
  scanf("%d", &numOfThreads);

  // creating threads using a loop

  pthread_t threadID[numOfThreads];

  for (int i = 0; i < numOfThreads; i++) {
    pthread_create(&threadID[i], NULL, worker1,
                   NULL); // starting threads for execution
  }

  for (int i = 0; i < numOfThreads; i++) {
    pthread_join(threadID[i], NULL);
  }

  return 0;
}
#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int N = 0;

void *countEvenNumbers(void *arg) {

  int *fibArray = (int *)arg;

  int count = 0;

  for (int i = 0; i < N; i++) {
    if (fibArray[i] % 2 == 0) {
      count++;
    }
  }

  int *countptr = malloc(sizeof(int));

  *countptr = count;

  printf("The thread ID of CountEven function is : %lu\n", pthread_self());

  pthread_exit(countptr);
}

void *countOddNumbers(void *arg) {

  int *fibArray = (int *)arg;

  int count = 0;

  for (int i = 0; i < N; i++) {
    if (fibArray[i] % 2 != 0) {
      count++;
    }
  }

  int *oddptr = malloc(sizeof(int));

  *oddptr = count;

  printf("The thread ID of CountODD function is : %lu\n", pthread_self());

  pthread_exit(oddptr);
}

void *fibonacciGenerator(void *arg) {

  int n = *(int *)arg;

  if (n < 1) {
    printf("Invalid Number\n");
    return NULL;
  }

  int *fibArray = (int *)malloc(n * sizeof(int));

  fibArray[0] = 0;
  fibArray[1] = 1;

  for (int i = 2; i < n; i++) {
    fibArray[i] = fibArray[i - 1] + fibArray[i - 2];
  }

  printf("The thread ID is : %lu\n", pthread_self());

  pthread_exit(fibArray);
}

int main(int argc, char **argv) {

  N = atoi(argv[1]);

  pthread_t thread;

  pthread_create(&thread, NULL, fibonacciGenerator, &N);

  printf("Main thread ID is : %lu\n", pthread_self());

  void *array;

  pthread_join(thread, &array);

  int *resultArray = (int *)array;

  for (int i = 0; i < N; i++) {
    printf("%d\n", (resultArray[i]));
  }

  //-------------------------------------------------------------------

  // now we need to pass this resultArray to another thread that will count the
  // even numbers

  pthread_t thread2;

  pthread_create(&thread2, NULL, countEvenNumbers, resultArray);

  void *countEven;

  pthread_join(thread2, &countEven);

  int *resultEven = (int *)countEven;

  printf("The count of Even numbers in the series is %d", *resultEven);

  //--------------------------------------------------------------------

  // now we need to pass this resultArray to another thread that will count the
  // odd numbers

  pthread_t thread3;

  pthread_create(&thread3, NULL, countOddNumbers, resultArray);

  void *countOdd;

  pthread_join(thread3, &countOdd);

  int *resultOdd = (int *)countOdd;

  printf("The count of Odd numbers in the series is %d", *resultOdd);
  return 0;
}
#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// global variables

int X, Y, Z, W, X1, W1, Y1, Z1;

sem_t sem1; // create semaphores
sem_t sem2;

void *worker1() // thread1
{
  printf("Kindly enter values for X and Y");

  scanf("%d %d", &X, &Y); // user input

  sem_post(&sem1); // increment operation

  sem_wait(&sem2); // decrement operation

  X1 = Z + 2;

  sem_post(&sem1);

  sem_wait(&sem2);

  Y1 = Z1 * 5;

  int S1 = X1 + Y1;

  printf("x = %d\n", S1);

  sem_post(&sem1);
}

void *worker2() // thread2
{
  sem_wait(&sem1);

  printf("Kindly enter values for W and Z");

  scanf("%d %d", &W, &Z); // user input

  sem_post(&sem2);

  sem_wait(&sem1);

  Z1 = X1 * 2;

  sem_post(&sem2);

  sem_wait(&sem1);

  W1 = Y1 + 5;

  int S2 = Z1 + W1;

  printf("x = %d\n", S2);
}

int main(int argc, char **argv) {
  sem_init(&sem1, 0, 0); // initialize semaphores
  sem_init(&sem2, 0, 0);

  pthread_t thread1; // initialize threads
  pthread_t thread2;

  pthread_create(&thread1, NULL, worker1, NULL); // create threads
  pthread_create(&thread2, NULL, worker2, NULL);

  pthread_join(thread1, NULL); // join threads, dont use & when joining threads
  pthread_join(thread2, NULL);

  return 0;
}